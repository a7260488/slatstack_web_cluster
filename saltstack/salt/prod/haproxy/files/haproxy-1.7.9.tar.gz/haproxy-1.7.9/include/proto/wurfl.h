#ifndef _PROTO_WURFL_H
#define _PROTO_WURFL_H

int ha_wurfl_init(void);
void ha_wurfl_deinit(void);

#endif
